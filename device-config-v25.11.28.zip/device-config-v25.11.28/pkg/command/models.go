package command 

type Command struct {
	Code        string
	Type        string
	Name        string
	ReadAction  string
	WriteAction string
}