package option

type Option struct {
	Name        string
	Flag        string
	Type        string
	Description string
}
