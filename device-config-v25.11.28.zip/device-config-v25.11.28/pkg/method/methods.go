package method

const Get string = "GET"
const Post string = "POST"

