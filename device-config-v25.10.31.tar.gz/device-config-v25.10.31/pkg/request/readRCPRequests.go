package request

import (
	cmd "gitlab.cbsdev.net/quality-assurance/device-config/pkg/command"
	dir "gitlab.cbsdev.net/quality-assurance/device-config/pkg/direction"
	mt "gitlab.cbsdev.net/quality-assurance/device-config/pkg/method"
	rcp "gitlab.cbsdev.net/quality-assurance/device-config/pkg/rcp"
)

func (r *Request) GetCapabilites() string {
	req := rcp.Request{
		IPAddress: r.Device.IPAddress,
		Password:  r.Device.Password,
		Method:    mt.Get,
		Command:   cmd.Capabilities.Code,
		Type:      cmd.Capabilities.Type,
		Direction: dir.Read,
	}
	return req.Send()
}

func (r *Request) GetMacAddress() (macAddress string) {
	req := rcp.Request{
		IPAddress: r.Device.IPAddress,
		Password:  r.Device.Password,
		Method:    mt.Get,
		Command:   cmd.MacAddress.Code,
		Type:      cmd.MacAddress.Type,
		Direction: dir.Read,
	}
	return req.Send()
}

func (r *Request) GetName() (name string) {
	req := rcp.Request{
		IPAddress: r.Device.IPAddress,
		Password:  r.Device.Password,
		Method:    mt.Get,
		Command:   cmd.Name.Code,
		Type:      cmd.Name.Type,
		Direction: dir.Read,
	}
	return req.Send()
}

func (r *Request) GetCloudDestination() (cloudDestination string) {
	req := rcp.Request{
		IPAddress: r.Device.IPAddress,
		Password:  r.Device.Password,
		Method:    mt.Get,
		Command:   cmd.CloudDestination.Code,
		Type:      cmd.CloudDestination.Type,
		Direction: dir.Read,
	}
	return req.Send()
}

func (r *Request) GetSocketKnockerDestination() (socketKnockerDestination string) {
	req := rcp.Request{
		IPAddress: r.Device.IPAddress,
		Password:  r.Device.Password,
		Method:    mt.Get,
		Command:   cmd.SocketKnockerDestination.Code,
		Type:      cmd.SocketKnockerDestination.Type,
		Direction: dir.Read,
	}
	return req.Send()
}

func (r *Request) GetFirmwareVersionFormatted() (firmwareVersion string) {
	req := rcp.Request{
		IPAddress: r.Device.IPAddress,
		Password:  r.Device.Password,
		Method:    mt.Get,
		Command:   cmd.FirmwareVersionFormatted.Code,
		Type:      cmd.FirmwareVersionFormatted.Type,
		Direction: dir.Read,
	}
	return req.Send()
}

func (r *Request) GetProductName() (productName string) {
	req := rcp.Request{
		IPAddress: r.Device.IPAddress,
		Password:  r.Device.Password,
		Method:    mt.Get,
		Command:   cmd.ProductName.Code,
		Type:      cmd.ProductName.Type,
		Direction: dir.Read,
	}
	return req.Send()
}

func (r *Request) GetSocketKnockerStatusAndReason() (socketKnockerStatusAndReason string) {
	req := rcp.Request{
		IPAddress: r.Device.IPAddress,
		Password:  r.Device.Password,
		Method:    mt.Get,
		Command:   cmd.SocketKnockerStatusReason.Code,
		Type:      cmd.SocketKnockerStatusReason.Type,
		Direction: dir.Read,
	}
	return req.Send()
}

func (r *Request) GetCloudStatus() (cloudStatus string) {
	req := rcp.Request{
		IPAddress: r.Device.IPAddress,
		Password:  r.Device.Password,
		Method:    mt.Get,
		Command:   cmd.CloudStatus.Code,
		Type:      cmd.CloudStatus.Type,
		Direction: dir.Read,
	}
	return req.Send()
}

func (r *Request) GetVCAProfile() (vcaProfile string) {
	req := rcp.Request{
		IPAddress: r.Device.IPAddress,
		Password:  r.Device.Password,
		Method:    mt.Get,
		Command:   cmd.VCAProfile.Code,
		Type:      cmd.VCAProfile.Type,
		Direction: dir.Read,
	}
	return req.Send()
}

func (r *Request) GetSocketKnockerMode() (socketknockerMode string) {
	req := rcp.Request{
		IPAddress: r.Device.IPAddress,
		Password:  r.Device.Password,
		Method:    mt.Get,
		Command:   cmd.SocketKnockerMode.Code,
		Type:      cmd.SocketKnockerMode.Type,
		Direction: dir.Read,
	}
	return req.Send()
}

func (r *Request) GetDateTimeYear() (dateTime string) {
	req := rcp.Request{
		IPAddress: r.Device.IPAddress,
		Password:  r.Device.Password,
		Method:    mt.Get,
		Command:   cmd.DateTimeYear.Code,
		Type:      cmd.DateTimeYear.Type,
		Direction: dir.Read,
	}
	return req.Send()
}

func (r *Request) GetDateTimeMonth() (dateTime string) {
	req := rcp.Request{
		IPAddress: r.Device.IPAddress,
		Password:  r.Device.Password,
		Method:    mt.Get,
		Command:   cmd.DateTimeMonth.Code,
		Type:      cmd.DateTimeMonth.Type,
		Direction: dir.Read,
	}
	return req.Send()
}

func (r *Request) GetDateTimeDay() (dateTime string) {
	req := rcp.Request{
		IPAddress: r.Device.IPAddress,
		Password:  r.Device.Password,
		Method:    mt.Get,
		Command:   cmd.DateTimeDay.Code,
		Type:      cmd.DateTimeDay.Type,
		Direction: dir.Read,
	}
	return req.Send()
}

func (r *Request) GetDateTimeHour() (dateTime string) {
	req := rcp.Request{
		IPAddress: r.Device.IPAddress,
		Password:  r.Device.Password,
		Method:    mt.Get,
		Command:   cmd.DateTimeHour.Code,
		Type:      cmd.DateTimeHour.Type,
		Direction: dir.Read,
	}
	return req.Send()
}

func (r *Request) GetDateTimeMinute() (dateTime string) {
	req := rcp.Request{
		IPAddress: r.Device.IPAddress,
		Password:  r.Device.Password,
		Method:    mt.Get,
		Command:   cmd.DateTimeMinute.Code,
		Type:      cmd.DateTimeMinute.Type,
		Direction: dir.Read,
	}
	return req.Send()
}

func (r *Request) GetDateTimeSecond() (dateTime string) {
	req := rcp.Request{
		IPAddress: r.Device.IPAddress,
		Password:  r.Device.Password,
		Method:    mt.Get,
		Command:   cmd.DateTimeSecond.Code,
		Type:      cmd.DateTimeSecond.Type,
		Direction: dir.Read,
	}
	return req.Send()
}

func (r *Request) GetDateTimeTimezoneOffset() (dateTime string) {
	req := rcp.Request{
		IPAddress: r.Device.IPAddress,
		Password:  r.Device.Password,
		Method:    mt.Get,
		Command:   cmd.DateTimeTimezoneOffset.Code,
		Type:      cmd.DateTimeTimezoneOffset.Type,
		Direction: dir.Read,
	}
	return req.Send()
}
