package command

const pUnicode string = "P_UNICODE"
const pOctet string = "P_OCTET"
const pString string = "P_STRING"
const tOctet string = "T_OCTET"
const tDword string = "T_DWORD"
const fFlag string = "F_FLAG"
const tInt string = "T_INT"
const tWord string = "T_WORD"
