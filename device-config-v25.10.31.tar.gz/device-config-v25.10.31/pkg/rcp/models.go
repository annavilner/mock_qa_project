package rcp

type Request struct {
	IPAddress string
	Password  string
	Method    string
	Command   string
	Type      string
	Direction string
	Payload   string
	Num       string
	IdString  string
}
