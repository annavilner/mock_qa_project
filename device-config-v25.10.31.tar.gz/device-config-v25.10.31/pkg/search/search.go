package search

import (
	"bufio"
	"fmt"
	"net"
	"os"
	"os/exec"
	"regexp"
	"runtime"
	"sort"
	"strings"
	"sync"
	"time"
)

const (
	cidr = "192.168.1.0/24"
)

func SearchDevices() (ips []string) {

	probeSubnet(cidr)
	pingSubnet(cidr)

	time.Sleep(300 * time.Millisecond)

	entries, err := readARPCache()
	if err != nil {
		fmt.Println("error reading ARP cache:", err)
		os.Exit(2)
	}

	for ip, _ := range entries {
		ips = append(ips, ip)
	}

	sort.Slice(ips, func(i, j int) bool {
		ip1 := net.ParseIP(ips[i]).To16()
		ip2 := net.ParseIP(ips[j]).To16()

		// reverse comparison for DESC
		for i := range len(ip1) {
			if ip1[i] > ip2[i] {
				return true
			}
			if ip1[i] < ip2[i] {
				return false
			}
		}
		return false
	})

	return
}

func SearchDevice(targetMac string) (ipAddress string) {
	if len(os.Args) < 3 {
		fmt.Println("usage: mac2ip_full <MAC> <CIDR>")
		os.Exit(1)
	}

	targetMac = normalizeMAC(targetMac)

	probeSubnet(cidr)
	pingSubnet(cidr)

	time.Sleep(300 * time.Millisecond)

	entries, err := readARPCache()
	if err != nil {
		fmt.Println("error reading ARP cache:", err)
		os.Exit(2)
	}

	var found []string
	for ip, mac := range entries {
		if normalizeMAC(mac) == targetMac {
			found = append(found, ip)
		}
	}
	
	if len(found) != 0 {
		ipAddress = found[0]
	}
	
	return
}

// -----------------------------
// Helper Functions
// -----------------------------

// probeSubnet does quick TCP dials to populate ARP cache (no sudo)
func probeSubnet(cidr string) {
	_, ipnet, err := net.ParseCIDR(cidr)
	if err != nil {
		fmt.Println("Invalid CIDR:", err)
		return
	}

	var addrs []string
	for ip := ipnet.IP.Mask(ipnet.Mask); ipnet.Contains(ip); inc(ip) {
		s := ip.String()
		if strings.HasSuffix(s, ".0") || strings.HasSuffix(s, ".255") {
			continue
		}
		addrs = append(addrs, s)
	}

	concurrency := 100
	sem := make(chan struct{}, concurrency)
	var wg sync.WaitGroup
	timeout := 250 * time.Millisecond
	ports := []string{"80", "443", "22", "53"} // common ports

	for _, a := range addrs {
		for _, p := range ports {
			wg.Add(1)
			sem <- struct{}{}
			go func(ipAddr, port string) {
				defer wg.Done()
				defer func() { <-sem }()
				addr := net.JoinHostPort(ipAddr, port)
				conn, _ := net.DialTimeout("tcp", addr, timeout)
				if conn != nil {
					conn.Close()
				}
			}(a, p)
		}
	}
	wg.Wait()
}

// pingSubnet uses system ping to populate ARP cache
func pingSubnet(cidr string) {
	_, ipnet, err := net.ParseCIDR(cidr)
	if err != nil {
		fmt.Println("Invalid CIDR:", err)
		return
	}

	var wg sync.WaitGroup
	for ip := ipnet.IP.Mask(ipnet.Mask); ipnet.Contains(ip); inc(ip) {
		s := ip.String()
		if strings.HasSuffix(s, ".0") || strings.HasSuffix(s, ".255") {
			continue
		}
		wg.Add(1)
		go func(ipAddr string) {
			defer wg.Done()
			cmd := "ping"
			args := []string{}
			if runtime.GOOS == "windows" {
				args = []string{"-n", "1", "-w", "100", ipAddr}
			} else {
				args = []string{"-c", "1", "-W", "1", ipAddr}
			}
			exec.Command(cmd, args...).Run()
		}(s)
	}
	wg.Wait()
}

// inc increments an IPv4 in place
func inc(ip net.IP) {
	for j := len(ip) - 1; j >= 0; j-- {
		ip[j]++
		if ip[j] != 0 {
			break
		}
	}
}

// readARPCache reads OS ARP table and returns map[ip]mac
func readARPCache() (map[string]string, error) {
	switch runtime.GOOS {
	case "linux":
		return parseProcNetARP("/proc/net/arp")
	case "darwin", "freebsd", "windows":
		return parseArpAOutput()
	default:
		return parseArpAOutput()
	}
}

// Linux /proc/net/arp parser
func parseProcNetARP(path string) (map[string]string, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	scanner := bufio.NewScanner(f)
	entries := make(map[string]string)
	first := true
	for scanner.Scan() {
		line := scanner.Text()
		if first {
			first = false
			continue
		}
		fields := strings.Fields(line)
		if len(fields) >= 4 {
			ip := fields[0]
			mac := fields[3]
			if mac != "00:00:00:00:00:00" && mac != "" {
				entries[ip] = mac
			}
		}
	}
	return entries, scanner.Err()
}

// macOS / Windows / generic arp -a parser
func parseArpAOutput() (map[string]string, error) {
	cmd := exec.Command("arp", "-a")
	out, err := cmd.Output()
	if err != nil {
		return nil, err
	}
	text := string(out)
	ipRe := regexp.MustCompile(`\d+\.\d+\.\d+\.\d+`)
	macRe := regexp.MustCompile(`(?i)([0-9a-f]{2}(?::|-)){5}[0-9a-f]{2}`)
	entries := make(map[string]string)
	scanner := bufio.NewScanner(strings.NewReader(text))
	for scanner.Scan() {
		line := scanner.Text()
		ip := ""
		mac := ""
		if m := ipRe.FindString(line); m != "" {
			ip = m
		}
		if mm := macRe.FindString(line); mm != "" {
			mac = strings.ReplaceAll(mm, "-", ":")
			mac = strings.ToLower(mac)
		}
		if ip != "" && mac != "" {
			entries[ip] = mac
		}
	}
	return entries, scanner.Err()
}

// normalizeMAC converts MAC to lowercase colon-separated
func normalizeMAC(m string) string {
	m = strings.TrimSpace(strings.ToLower(m))
	m = strings.ReplaceAll(m, "-", ":")
	parts := strings.Split(m, ":")
	if len(parts) == 6 {
		for i := range parts {
			if len(parts[i]) == 1 {
				parts[i] = "0" + parts[i]
			}
		}
		return strings.Join(parts, ":")
	}
	return m
}