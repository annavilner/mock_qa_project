package direction

const Read string = "READ"
const Write string = "WRITE"