export const API_BASE_URL =
  'https://f6b2a073-3ae1-447f-9f7e-a9eb76502794.mock.pstmn.io';

